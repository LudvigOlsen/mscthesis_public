# mscthesis

This is the code for my master thesis project as Aarhus University, Spring 2021.
