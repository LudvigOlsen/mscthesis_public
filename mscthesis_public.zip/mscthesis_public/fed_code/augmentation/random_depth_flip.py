
import random


class RandomDepthFlip:

    def __init__(self, prob=0.5):
        self.prob = prob

    def __call__(self, datapoint):
        assert len(datapoint['data'].shape) == 4, \
            'RandomDepthFlip can only be used on 4D tensors (slice, channel, height, width)'

        if random.uniform(0.0, 1.0) < self.prob:
            # Flip the slice direction
            new_data = datapoint['data'].clone().flip((0))
            new_brain = datapoint['brain'].clone().flip((0))
            datapoint['data'] = new_data
            datapoint['brain'] = new_brain

        return datapoint
