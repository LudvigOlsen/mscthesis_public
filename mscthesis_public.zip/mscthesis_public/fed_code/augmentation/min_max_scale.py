"""
This module contains the MinMaxScale transformer.

"""

class MinMaxScale:  # pylint: disable=too-few-public-methods
    """
    MinMax scale an image.
    """

    def __init__(self, new_min, new_max, old_min, old_max):
        """
        Create `MinMaxScale` transformer instance.

        :param new_min: The new allowed minimum value.
        :param new_max: The new allowed maximum value.
        :param old_min: Originally allowed minimum value.
        :param old_max: Originally allowed maximum values.
        """
        self.new_min = new_min
        self.new_max = new_max
        self.old_min = old_min
        self.old_max = old_max

    def __call__(self, datapoint):

        # Clone data to avoid side effects
        new_data = datapoint['data'].clone()

        # Scale to range
        old_diff = self.old_max - self.old_min

        # Avoid zero-division
        if old_diff == 0:
            old_diff = 1

        # Scale to new range
        new_data_std = (new_data - self.old_min) / old_diff
        new_data = new_data_std * (self.new_max - self.new_min) + self.new_min

        datapoint['data'] = new_data

        return datapoint
