

class RepeatChannel:

    def __init__(self, num_reps=3):
        self.num_reps = num_reps

    def __call__(self, datapoint):
        new_data = datapoint['data'].clone()
        new_brain = datapoint['brain'].clone()
        new_data = new_data.repeat(self.num_reps, 1, 1, 1).permute(1, 0, 2, 3)
        new_brain = new_brain.repeat(self.num_reps, 1, 1, 1).permute(1, 0, 2, 3)
        datapoint['data'] = new_data
        datapoint['brain'] = new_brain
        return datapoint
