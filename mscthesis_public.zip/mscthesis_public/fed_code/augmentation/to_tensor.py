
import torch

class ToTensor:

    def __call__(self, datapoint, fn=torch.FloatTensor):
        keys_to_convert = ['data', 'brain', 'label_idx']
        for key in keys_to_convert:
            datapoint[key] = fn(datapoint[key])
        return datapoint
