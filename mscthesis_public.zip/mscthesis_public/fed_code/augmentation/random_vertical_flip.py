
import random


class RandomVerticalFlip:

    def __init__(self, prob=0.5):
        self.prob = prob

    def __call__(self, datapoint):

        if random.uniform(0.0, 1.0) < self.prob:
            new_data = datapoint['data'].clone().flip((-2))
            new_brain = datapoint['brain'].clone().flip((-2))
            datapoint['data'] = new_data
            datapoint['brain'] = new_brain

        return datapoint
