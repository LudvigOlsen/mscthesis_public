
import random
import torch


class RandomTranslate:

    def __init__(self, max_x, max_y, fill=0):
        assert isinstance(max_x, int) and isinstance(max_y, int)
        self.max_x = max_x
        self.max_y = max_y
        self.fill = fill

    def __call__(self, datapoint):
        data = datapoint['data'].clone()
        brain = datapoint['brain'].clone()

        move_x = random.randint(-self.max_x, self.max_x)
        move_y = random.randint(-self.max_y, self.max_y)

        # In case we don't want to move, no need to do anything else
        if move_x == 0 and move_y == 0:
            return datapoint

        # Create positional masks
        old_pos_mask, new_pos_mask = self._create_positional_masks(data=data, move_x=move_x, move_y=move_y)

        # Init new tensors
        new_data = torch.zeros_like(data) + self.fill
        new_brain = torch.zeros_like(brain)

        # Add the original data in its new location
        new_data[new_pos_mask == 1] = data[old_pos_mask == 1]
        new_brain[new_pos_mask == 1] = brain[old_pos_mask == 1]

        datapoint['data'] = new_data
        datapoint['brain'] = new_brain

        return datapoint

    def _create_positional_masks(self, data, move_x, move_y):
        """
        Create two masks with the positions where the original data is placed
        and where it will be placed after the translation.
        """
        old_pos_mask = torch.zeros_like(data)
        new_pos_mask = torch.zeros_like(data)

        if move_x == 0:
            if move_y < 0:
                old_pos_mask[:, :, :, -move_y:] = 1
                new_pos_mask[:, :, :, :move_y] = 1
            else:
                old_pos_mask[:, :, :, :-move_y] = 1
                new_pos_mask[:, :, :, move_y:] = 1
        elif move_x < 0:
            if move_y < 0:
                old_pos_mask[:, :, -move_x:, -move_y:] = 1
                new_pos_mask[:, :, :move_x, :move_y] = 1
            elif move_y > 0:
                old_pos_mask[:, :, -move_x:, :-move_y] = 1
                new_pos_mask[:, :, :move_x, move_y:] = 1
            else:
                old_pos_mask[:, :, -move_x:, :] = 1
                new_pos_mask[:, :, :move_x, :] = 1
        else:
            if move_y < 0:
                old_pos_mask[:, :, :-move_x, -move_y:] = 1
                new_pos_mask[:, :, move_x:, :move_y] = 1
            elif move_y > 0:
                old_pos_mask[:, :, :-move_x, :-move_y] = 1
                new_pos_mask[:, :, move_x:, move_y:] = 1
            else:
                old_pos_mask[:, :, :-move_x, :] = 1
                new_pos_mask[:, :, move_x:, :] = 1

        return old_pos_mask, new_pos_mask
