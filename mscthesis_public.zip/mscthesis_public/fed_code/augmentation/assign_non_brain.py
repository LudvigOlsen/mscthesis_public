

class AssignNonBrain:

    def __init__(self, value=0.):
        self.value = value

    def __call__(self, datapoint):
        """
        Sets non-brain pixels to a specific values.
        The non-brain pixels in the brain mask are set to 0.0 as well.
        """
        new_data = datapoint['data'].clone()
        new_brain = datapoint['brain'].clone()
        new_data[new_brain != 1] = self.value
        new_brain[new_brain != 1] = 0.0
        datapoint['data'] = new_data
        datapoint['brain'] = new_brain
        return datapoint
