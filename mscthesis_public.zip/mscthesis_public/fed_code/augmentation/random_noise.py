
import torch
import random

from fed_code.utils.math import percentile
from fed_code.utils.blend import blend


class RandomNoise:

    def __init__(self, max_amount, noise_type):
        self.max_amount = max_amount
        self.noise_type = noise_type

    def __call__(self, datapoint):
        new_data = datapoint['data'].clone()
        brain = datapoint['brain']
        amount = random.uniform(0, self.max_amount)
        new_data = self._add_noise(data=new_data, mask=brain, amount=amount)
        datapoint['data'] = new_data
        return datapoint

    def _add_noise(self, data, mask, amount):
        if self.noise_type == 'sp':
            # Salt and pepper
            new_data = RandomNoise._generate_salt_and_pepper(data=data, mask=mask, amount=amount)
        elif self.noise_type == 'robust_gaussian':
            # Gaussian where location=median and scale=IQR
            noise = RandomNoise._generate_robust_gaussian(data=data, mask=mask)
            new_data = blend(x1=data, x2=noise, amount=amount)

        # Ensure non-brain remains intact
        new_data = RandomNoise._restore_non_brain(new_data=new_data, old_data=data, mask=mask)
        return new_data

    @staticmethod
    def _generate_salt_and_pepper(data, mask, amount):
        """
        Randomly replace some pixels with the min/max values in `data`.
        Only brain pixels are used to calculate min/max values.
        """
        # Extract values to inject
        max_pixel = data[mask == 1].max()
        min_pixel = data[mask == 1].min()

        # Calculate which probability intervals lead to salt, pepper or original
        amount_each = amount / 2
        prob_tensor = torch.rand_like(data)

        # Sprinkle some salt and pepper
        # Start by cloning the data to avoid side effects
        noised_data = data.clone()
        # Lowest amount/2 probabilities gets pepper
        noised_data[prob_tensor < amount_each] = min_pixel
        # Highest amount/2 probabilities gets salt
        noised_data[prob_tensor > 1.0 - amount_each] = max_pixel
        return noised_data

    @staticmethod
    def _generate_robust_gaussian(data, mask):
        """
        A Gaussian distribution based on the median and IQR of the original data.
        Only the brain pixels are used for calculating statistics.
        """
        median = percentile(data[mask == 1], 50)
        iqr = percentile(data[mask == 1], 75) - percentile(data[mask == 1], 25)
        return torch.normal(mean=median, std=iqr, size=list(data.shape))

    @staticmethod
    def _restore_non_brain(new_data, old_data, mask):
        new_data[mask != 1] = old_data[mask != 1]
        return new_data
