

import torch
from torchvision import transforms
import numpy as np

from fed_code.augmentation import MinMaxScale, ToTensor, RepeatChannel, Standardize, AssignNonBrain, CenterCrop, Truncate
from fed_code.augmentation import RandomNoise, RandomTranslate, RandomValueOffset
from fed_code.augmentation import RandomVerticalFlip, RandomDepthFlip, RandomHorizontalFlip


class test_transform:

    def __init__(self, lowest_allowed, highest_allowed, hparams):
        self.apply_first_n = None
        self.transformers = [
            ToTensor(),
            Truncate(lower=lowest_allowed, upper=highest_allowed),
            MinMaxScale(new_min=0., new_max=1., old_min=lowest_allowed, old_max=highest_allowed),
            RepeatChannel(3),  # Repeat channel to "RGB"
            Standardize(mean=[0.485, 0.456, 0.406],  # Specific for pretrained networks in torch
                        std=[0.229, 0.224, 0.225]),
            AssignNonBrain(value=0.0),
            CenterCrop(hparams.aug_center_crop_size),
        ]
        self.transform = transforms.Compose(self.transformers)

    def __call__(self, data):
        if self.apply_first_n is None:
            return self.transform(data)
        else:
            return transforms.Compose(self.transformers[0:self.apply_first_n])(data)

    def __len__(self):
        return len(self.transformers)


class train_transform:

    def __init__(self, lowest_allowed, highest_allowed, hparams):
        self.apply_first_n = None
        self.transformers = [
            test_transform(lowest_allowed=lowest_allowed, highest_allowed=highest_allowed, hparams=hparams),
            RandomValueOffset(max_offset=hparams.aug_max_offset),
            RandomNoise(max_amount=hparams.aug_max_amount_robust_gaussian, noise_type='robust_gaussian'),  # Blends in Normal(median, IQR)
            RandomNoise(max_amount=hparams.aug_max_amount_salt_pepper, noise_type='sp'),  # Adds Salt and Pepper
            RandomTranslate(max_x=hparams.aug_max_translate_xy[0], max_y=hparams.aug_max_translate_xy[1]),
            RandomDepthFlip(prob=hparams.aug_prob_depth_flip),
            RandomHorizontalFlip(prob=hparams.aug_prob_horizontal_flip),
            RandomVerticalFlip(prob=hparams.aug_prob_vertical_flip),
        ]
        self.transform = transforms.Compose(self.transformers)

    def __call__(self, data):
        if self.apply_first_n is None:
            return self.transform(data)
        else:
            return transforms.Compose(self.transformers[0:self.apply_first_n])(data)

    def __len__(self):
        return len(self.transformers)
