
import torch
import numpy as np

class RandomValueOffset:

    def __init__(self, max_offset=0.5):
        self.max_offset = max_offset

    def __call__(self, datapoint):
        new_data = datapoint['data'].clone()
        brain = datapoint['brain']
        # Get random offset per channel
        offset = np.random.uniform(low=-self.max_offset, high=self.max_offset, size=new_data.shape[1])
        offset = torch.tensor(offset).unsqueeze(-1).unsqueeze(-1)
        # Apply offset to brain pixels
        new_data += (brain * offset)
        datapoint['data'] = new_data
        return datapoint
