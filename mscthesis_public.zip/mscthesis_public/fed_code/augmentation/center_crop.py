
import torch


class CenterCrop:

    def __init__(self, crop_size):
        self.crop_size = crop_size

        assert self.crop_size[1] == 3, 'Channel dimension (1) must be `3`.'

    def __call__(self, datapoint):
        new_data = datapoint['data'].clone()
        new_brain = datapoint['brain'].clone()
        assert len(new_data.size()) == 4, '`CenterCrop` must be called after adding the channels dimension.'
        new_data = CenterCrop._center_crop(new_data, out_size=self.crop_size)
        new_brain = CenterCrop._center_crop(new_brain, out_size=self.crop_size)
        datapoint['data'] = new_data
        datapoint['brain'] = new_brain
        return datapoint

    @staticmethod
    def _center_crop(data, out_size):
        """
        Crops around center to `out_size`.
        """
        # Check shapes are 3-D (plus channels)
        assert len(out_size) == 4
        orig_shape = torch.tensor(data.size())
        assert len(orig_shape) == 4

        # Calculate start and end coordinates
        to_cut = orig_shape - torch.tensor(out_size)
        to_cut_left = to_cut // 2
        to_cut_right = to_cut - to_cut_left
        # Cropping from right with negative indices
        to_cut_right *= -1

        # If any right cuts are 0 we must get the full length (because -0 -> 0)
        # The double brackets are necessary, as 1D boolean indexing does not work
        to_cut_right[[to_cut_right == 0]] = orig_shape[[to_cut_right == 0]]

        # Extract the dimension coordinates
        dim_1_start, dim_2_start, dim_3_start, dim_4_start = to_cut_left
        dim_1_end, dim_2_end, dim_3_end, dim_4_end = to_cut_right

        # Crop the image
        # Second dim is the channels dim
        return data[dim_1_start:dim_1_end, dim_2_start:dim_2_end, dim_3_start:dim_3_end, dim_4_start:dim_4_end]
