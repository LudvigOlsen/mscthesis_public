

class Truncate:

    def __init__(self, lower, upper):
        self.lower = lower
        self.upper = upper

    def __call__(self, datapoint):
        """
        Removes outliers.
        """
        new_data = datapoint['data'].clone()
        new_data[new_data < self.lower] = self.lower
        new_data[new_data > self.upper] = self.upper
        datapoint['data'] = new_data
        return datapoint
