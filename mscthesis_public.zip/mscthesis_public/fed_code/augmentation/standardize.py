
import torch
from torchvision import transforms

class Standardize:

    def __init__(self, mean, std):
        self.mean = torch.tensor(mean).unsqueeze(-1).unsqueeze(-1)
        self.std = torch.tensor(std).unsqueeze(-1).unsqueeze(-1)

    def __call__(self, datapoint):
        new_data = datapoint['data'].clone()
        new_data -= self.mean
        new_data /= self.std
        datapoint['data'] = new_data
        return datapoint
