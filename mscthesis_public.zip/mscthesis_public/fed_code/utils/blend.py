

def blend(x1, x2, amount):
    """
    Blend two tensors.
    """
    x1_weighted = x1.clone() * (1 - amount)
    x2_weighted = x2 * amount
    blended = x1_weighted + x2_weighted
    return blended
