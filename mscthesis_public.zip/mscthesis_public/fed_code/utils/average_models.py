
import torch
import numpy as np


def average_models(models, weights, out_model):
    state_dicts = [mod.state_dict() for mod in models]
    new_state_dict = _average_state_dicts(state_dicts, weights)
    out_model.load_state_dict(new_state_dict)
    return out_model


def average_optimizers(optimizers, weights, out_optimizer):
    state_dicts = [optim.state_dict() for optim in optimizers]
    new_state_dict = _average_state_dicts(state_dicts, weights)
    out_optimizer.load_state_dict(new_state_dict)
    return out_optimizer


def _average_state_dicts(state_dicts, weights):
    assert len(weights) == len(state_dicts)
    assert np.round(np.sum(weights), decimals=2) == 1.0
    first_state_dict = state_dicts[0]
    for key in first_state_dict.keys():
        first_state_dict[key] = average_list_of_tensors([d[key] for d in state_dicts], weights=weights)
    return first_state_dict


def average_list_of_tensors(xs, weights=None):
    if not isinstance(xs[0], torch.Tensor):
        return xs[0]

    if weights is None:
        # Standard averaging
        return torch.mean(torch.stack(xs), dim=0, keep_dims=True).squeeze(0)

    # Weighted averaging
    weighted_xs = [x * w for x,w in zip(xs, weights)]
    return torch.sum(torch.stack(weighted_xs), dim=0)
