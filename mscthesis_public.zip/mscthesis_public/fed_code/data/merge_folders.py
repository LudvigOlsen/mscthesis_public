"""
This script merges a source folder into a destination folder.
NOTE: Currently only .nii and .xml files are copied.
If a file already exists in the destination folder, it is skipped (no overwriting).
"""

import argparse
import pathlib
import shutil


def make_dirs(file_path):
    # Create output folder
    try:
        output_folder = pathlib.Path(file_path).absolute().parents[0]
        output_folder.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        raise RuntimeError('Could not create folder: ', str(e))


def find_files(path, ext='.nii'):
    """
    Find files recursively.

    :return:
        - Sorted list of files
    """
    return pathlib.Path(path).rglob('*' + ext)


def merge_folders(source_path, target_path, extensions=['.nii', '.xml']):
    target_path = pathlib.Path(target_path).absolute()
    source_path = pathlib.Path(source_path).absolute()
    source_path_str = str(source_path) + '/'

    move_map = {}
    for ext in extensions:
        source_files = [str(f.absolute()) for f in find_files(source_path, ext=ext)]
        print(source_files[0], source_path)
        target_paths = [target_path / fpath[len(source_path_str):] for fpath in source_files]
        for src_path, trgt_path in zip(source_files, target_paths):
            move_map[src_path] = trgt_path

    print('Will copy ', len(move_map.keys()), ' files.')

    num_skipped = 0
    for src, dst in move_map.items():
        if dst.is_file():
            num_skipped += 1
            print(f'This file already exists. Skipping: {dst}')
        make_dirs(file_path=dst)
        shutil.copy2(src, dst)

    print(f'Finished merging folders. Skipped {num_skipped} files.')


if __name__ == '__main__':

    arg_parser = argparse.ArgumentParser(description='Merge data folders (.nii and .xml files only).')
    arg_parser.add_argument(
        'source', help='Path to source folder. Will recursively find .nii and .xml files from here and merge them into thetarget folder.')
    arg_parser.add_argument('target', help='Path to target folder. Must exist.')
    args = arg_parser.parse_args()

    # Merge the source folder files (.xml and .nii) into the target folder
    merge_folders(source_path=args.source, target_path=args.target)
