
from collections.abc import Iterable

class Clients:
    """
    Class for storing data and info for multiple clients.
    """

    def __init__(self):
        self.clients = {}
        self.names = []

    def add_client(self, training_data, test_data, name):
        client = Client(training_data=training_data, test_data=test_data, name=name)
        self._add_client(client)

    def _add_client(self, client):
        assert isinstance(client, Client)
        if client.name in self.clients:
            raise ValueError(f'`name` "{client.name}" already exists.')
        self.clients[client.name] = client
        self.names.append(client.name)

    def __len__(self):
        return len(self.names)

    def __getitem__(self, idx):
        if isinstance(idx, (slice, Iterable)):
            return [self.get_client(name=name) for name in self.names[idx]]
        return self.get_client(name=self.names[idx])

    def get_client(self, name):
        if name not in self.names:
            raise ValueError(f'`name` "{name}" not recognized.')
        return self.clients[name]

    def get_local(self):
        """
        The first client is the local "client"/worker.

        :return: A Clients container with only the first client.
        """
        clients = Clients()
        clients._add_client(self[0])
        return clients

    def get_nonlocals(self):
        """
        Get all but the first client (the local worker).

        :return: A Clients container with all but the first client.
        """
        clients = Clients()
        for cli in self[1:]:
            clients._add_client(cli)
        return clients

    def set_test_transform(self, transform):
        for name in self.names:
            self.clients[name].test_data.transform = transform

    def set_train_transform(self, transform):
        for name in self.names:
            self.clients[name].training_data.transform = transform

    def get_train_statistics(self):
        statistics_dicts = {}
        for name in self.names:
            statistics_dicts[name] = self.clients[name].training_data.statistics
        return statistics_dicts

    def get_test_statistics(self):
        statistics_dicts = {}
        for name in self.names:
            statistics_dicts[name] = self.clients[name].test_data.statistics
        return statistics_dicts

    def get_augmented_train_statistics(self):
        statistics_dicts = {}
        for name in self.names:
            statistics_dicts[name] = self.clients[name].training_data._calculate_statistics()
        return statistics_dicts

    def get_augmented_test_statistics(self):
        statistics_dicts = {}
        for name in self.names:
            statistics_dicts[name] = self.clients[name].test_data._calculate_statistics()
        return statistics_dicts

    def get_max_train_value(self):
        max_vals = []
        for name in self.names:
            max_vals.append(self.clients[name].training_data.statistics['max'])
        return max(max_vals)

    def get_min_train_value(self):
        min_vals = []
        for name in self.names:
            min_vals.append(self.clients[name].training_data.statistics['min'])
        return min(min_vals)

    def get_min_lower_5_train_value(self):
        lower_5_vals = []
        for name in self.names:
            lower_5_vals.append(self.clients[name].training_data.statistics['lower_05'])
        return min(lower_5_vals)

    def get_max_upper_95_train_value(self):
        upper_95_vals = []
        for name in self.names:
            upper_95_vals.append(self.clients[name].training_data.statistics['upper_95'])
        return max(upper_95_vals)

    def get_mean_train_value(self):
        total = 0
        brain_pixel_count = 0
        for name in self.names:
            stats = self.clients[name].training_data.statistics
            total += stats['mean'] * stats['num_brain_pixels']
            brain_pixel_count += stats['num_brain_pixels']
        return total / brain_pixel_count

    def __str__(self):
        lines = []
        lines.append('Client collection:')
        for i, _ in enumerate(self):
            lines.append(str(self[i]))
        return '\n  '.join(lines)


class Client:
    """
    Class for storing training and test data for a single client.
    """

    def __init__(self, training_data, test_data, name):
        self.training_data = training_data
        self.test_data = test_data
        self.name = name

    def __str__(self):
        name = Client._format_str(self.name, 15)
        train = Client._format_str(len(self.training_data), 4)
        test = Client._format_str(len(self.test_data), 4)
        return f'Client: {name} Train: {train} Test: {test}'

    @staticmethod
    def _format_str(string, max_len, add_dot=True):
        string = str(string)
        spaces = ''.join([' '] * (max_len - len(string)))
        string = string[:max_len]
        if add_dot:
            string += '.'
        return string + spaces
