"""
Dataset class for the ADNI data.
"""

import os
import pathlib
import numpy as np
import pandas as pd
import nibabel as nib
import torch
from torch.utils.data import Dataset
from torch.utils.data.sampler import WeightedRandomSampler


class ADNIDataset(Dataset):  # pylint: disable=too-many-instance-attributes,too-many-public-methods
    """
    Dataset for the ADNI data.
    """

    def __init__(self, subjects_info, subject_dirs_path, labels_dict, client=None, is_test=None, name=''):
        """
        Construct a dataset.
        """
        super().__init__()

        self.subjects_info = subjects_info
        self.subject_dirs_path = subject_dirs_path
        self.label_name_to_idx_dict = labels_dict
        self.label_idx_to_name_dict = {idx: key for key, idx in labels_dict.items()}
        self.client = client
        self.is_test = is_test
        self.name = name
        self.transform = None

        assert self.client is not None, '`client` name must be specified.'
        assert isinstance(self.is_test, bool), '`is_test` must be a boolean flag.'

        # Init data vars
        self.data = []
        self.brain_masks = []
        self.labels = []
        self.subject_ids = []
        self.session_ids = []

        self.total_num_slices = 0

        for idx, sub in enumerate(self.subjects_info):
            if idx % 20 == 0:
                print(f'Loaded {idx}/{len(self.subjects_info)}.', end='\r')
            self.read_subject({'subject_id': sub[0], 'label': sub[1]})
        print(f'Finished loading data: {len(self.subjects_info)}/{len(self.subjects_info)}.')

        self.statistics = self._calculate_statistics()

    def __len__(self):
        """
        Get the total number of samples represented by this dataset.

        :return: Total number of samples (studies or slices) represented by this dataset.
        """
        return len(self.data)

    def __getitem__(self, idx):
        """
        Get a sample. A sample consists of slice(s) of data (containing a number of channels), a brain mask, and a lesion mask.

        For 2D, a sample is a slice.
        For 3D, a sample is a volume. Use `get_slice()` to get a specific slice.

        :param idx: Index of the sample to get.
        :return: The sample (tuple)
        """
        if torch.is_tensor(idx):
            idx = idx.tolist()

        # The output can be one of tensors, numpy arrays, numbers, dicts or lists
        # for the default_collate function at least (batching related)
        datapoint = {'data': self.data[idx],
                     'brain': self.brain_masks[idx],
                     'label_idx': self.get_label_idx(self.labels[idx]),
                     'label_name': self.labels[idx],
                     'subject_id': self.subject_ids[idx],
                     'scan_id': self.session_ids[idx]}

        if self.transform is not None:
            datapoint = self.transform(datapoint) # pylint: disable=not-callable
            # Remove the additional dimension and convert to long
            datapoint['label_idx'] = datapoint['label_idx'].squeeze(0).long()

        return datapoint

    def _calculate_statistics(self):
        pixels = []
        for idx in range(len(self)):
            dp = self[idx]
            data = dp['data']
            brain = dp['brain']
            if brain.sum() < 1:
                continue
            if self.transform is not None:
                data = data.numpy()
                brain = brain.numpy()
            vals = list(data[brain == 1].flatten())
            pixels += vals

        pixels = np.asarray(pixels)

        return {
            'num_brain_pixels': pixels.size,
            'mean': np.mean(pixels),
            'std': np.std(pixels),
            'min': np.min(pixels),
            'max': np.max(pixels),
            'upper_95': np.percentile(pixels, 95),
            'lower_05': np.percentile(pixels, 5)
        }

    def get_label_idx(self, label_name):
        """
        Get label index in a list.

        Note: We return as list so `FloatTensor` will convert to tensor, not create a tensor with `label_idx` random elements.
        """
        return [self.label_name_to_idx_dict[label_name]]

    def get_label_name(self, label_idx):
        return self.label_idx_to_name_dict[label_idx]

    def read_subject(self, subject_info):
        subject_path = self.subject_dirs_path / subject_info['subject_id']
        session_paths = subject_path.glob('ses-*/')
        for sess in session_paths:
            sess_data_path = sess.absolute() / 't1w.nii.gz'
            sess_brain_path = sess.absolute() / 'brain.nii.gz'

            # Load subject's data and append to dataset
            self.data.append(nib.load(str(sess_data_path)).get_fdata())
            self.brain_masks.append(nib.load(str(sess_brain_path)).get_fdata())

            # Append subject and session info
            self.labels.append(subject_info['label'])
            self.subject_ids.append(subject_info['subject_id'])
            self.session_ids.append(sess.name)

    def get_data_loader(self, batch_size, n_workers, sample):
        """
        Create and return a `DataLoader` that contains the training dataset.
        Samples (studies or slices) are sampled randomly when iterating over the `DataLoader`.

        :param batch_size: Size of batches in `DataLoader`.
        :param n_workers: Use this many processes to load samples
        :param sample: Whether to perform weighted sampling. Disable when testing.
        :return: `DataLoader` object containing the training dataset
        """

        # TODO Generalize to any number of classes
        n_samples = len(self)
        n_samples_AD = sum([1 for label in self.labels if label == 'AD'])
        n_samples_MCI = sum([1 for label in self.labels if label == 'MCI'])
        n_samples_CN = sum([1 for label in self.labels if label == 'CN'])
        assert n_samples == sum([n_samples_AD, n_samples_MCI, n_samples_CN])

        if sample:
            weights_dict = {
                'AD': 1 / n_samples_AD,
                'MCI': 1 / n_samples_MCI,
                'CN': 1 / n_samples_CN
            }

            weights = [weights_dict[label] for label in self.labels]
            sampler = WeightedRandomSampler(weights, len(self))
            data_loader = torch.utils.data.DataLoader(self, sampler=sampler, batch_size=batch_size, num_workers=n_workers)
        else:
            data_loader = torch.utils.data.DataLoader(self, batch_size=batch_size, num_workers=n_workers)
        return data_loader
