"""
This script runs through the data folders and extract the relevant attributes
from the xml meta data files.
"""

# import pathlib
import glob
from collections import OrderedDict
import pandas as pd
from xml.etree import ElementTree as ET


#### Finding xml attributes ####

class Condition:

    def __init__(self, output=None, success=False, side_effect=None):
        """
        Store output and side effects to better handle errors during long runs.
        """
        self.output = output
        self.success = success
        self.side_effect = side_effect


def find_rec(node, element, result):
    for item in node.findall(element):
        result.append(item)
        find_rec(item, element, result)
    return result


def get_single(root, pattern, get_text=True):
    out = Condition()
    try:
        matches = root.findall(f'.//{pattern}')
        assert len(matches) == 1, f'expected 1 match for `{pattern}`, found {len(matches)} matches.'
        out.output = matches[0]
        if get_text:
            out.output = out.output.text
        out.success = True
    except Exception as e:
        out.side_effect = str(e)
        print(out.side_effect)
    return out


def get_one_of(root, pattern, attr_key, attr_val, get_text=True):
    out = Condition()
    try:
        matches = root.findall(f'.//{pattern}')
        matches = list(filter(lambda x: x.attrib[attr_key] == attr_val, matches))
        assert len(
            matches) == 1, f'expected 1 match for `{str(pattern)}` with the attribute `{str(attr_key)} = {attr_val}`, found {len(matches)} matches.'
        out.output = matches[0]
        if get_text:
            out.output = out.output.text
        out.success = True
    except Exception as e:
        out.side_effect = str(e)
        print(out.side_effect)
    return out

#### Storing patient meta data ####


class MetaDataDict:

    def __init__(self):
        self._keys = [
            'project_identifier', 'project_description', 'site_key',
            'subject_identifier', 'research_group',
            'subject_sex', 'subject_APOE_A1',
            'subject_APOE_A2', 'visit_identifier',
            'study_identifier', 'subject_age',
            'age_qualifier', 'weight_kg',
            'post_mortem', 'series_identifier',
            'modality', 'date_acquired',
            'annotation', 'derived_image_UID',
            'processed_data_label', 'image_type',
            'tissue', 'hemisphere',
            'anatomic_structure', 'related_image_UID',
            'registration',  # 'provenance_details',
            'creation_date', 'image_rating_description',
            'image_rating_value', 'seq_description',
            'seq_weighting', 'seq_pulse',
            'seq_slice_thickness', 'seq_TE',
            'seq_TR', 'seq_TI',
            'seq_coil', 'seq_flip_angle',
            'seq_acquisition_plane', 'seq_matrix_x',
            'seq_matrix_y', 'seq_matrix_z',
            'seq_pixel_spacing_x', 'seq_pixel_spacing_y',
            'seq_manufacturer', 'seq_mfg_model',
            'seq_field_strength'
        ]
        self.dict = OrderedDict([
            (key, None) for key in self._keys
        ])
        self.dict['side_effects'] = []
        self.is_finalized = False

    def add(self, condition, name):
        if self.is_finalized:
            raise RuntimeError("`dict` has been finalized and cannot be mutated.")
        if name not in self.dict:
            raise ValueError(f'`{name}` is not a key in the meta dict.')
        if condition.success:
            self.dict[name] = condition.output
        else:
            self.dict['side_effects'].append(condition.side_effect)

    def finalize(self):
        if self.is_finalized:
            raise RuntimeError("`dict` was already finalized.")
        self._finalize_side_effects()
        self._finalize_unset()
        self.is_finalized = True

    def _finalize_side_effects(self):
        self.dict['side_effects'] = "; ".join(self.dict['side_effects'])

    def _finalize_unset(self):
        def _replace_unset(x):
            cond1 = x is None
            cond2 = isinstance(x, list) and len(x) == 0
            if cond1 or cond2:
                return ""
            return x
        self.dict = OrderedDict((key, _replace_unset(val)) for key, val in self.dict.items())

    @property
    def as_data_frame(self):
        if not self.is_finalized:
            raise RuntimeError("`dict` must be finalized before conversion to data frame. Use `.finalize()`.")
        dict_copy = self.dict.copy()
        dict_copy['side_effects'] = "; ".join(dict_copy['side_effects'])
        return pd.DataFrame(self.dict, columns=self.dict.keys(), index=[0])


def read_meta_file(path):
    tree = ET.parse(path)
    root = tree.getroot()
    meta_dict = MetaDataDict()

    # print(dir(root))
    meta_dict.add(get_single(root, "projectIdentifier"), "project_identifier")
    meta_dict.add(get_single(root, "projectDescription"), "project_description")
    meta_dict.add(get_single(root, "siteKey"), "site_key")
    meta_dict.add(get_single(root, "subjectIdentifier"), "subject_identifier")
    meta_dict.add(get_single(root, "researchGroup"), "research_group")
    meta_dict.add(get_single(root, "subjectSex"), "subject_sex")
    meta_dict.add(get_one_of(root, "subjectInfo", 'item', "APOE A1"), "subject_APOE_A1")
    meta_dict.add(get_one_of(root, "subjectInfo", 'item', "APOE A2"), "subject_APOE_A2")
    meta_dict.add(get_single(root, "visitIdentifier"), "visit_identifier")
    meta_dict.add(get_single(root, "studyIdentifier"), "study_identifier")
    meta_dict.add(get_single(root, "subjectAge"), "subject_age")
    meta_dict.add(get_single(root, "ageQualifier"), "age_qualifier")
    meta_dict.add(get_single(root, "weightKg"), "weight_kg")
    meta_dict.add(get_single(root, "postMortem"), "post_mortem")
    meta_dict.add(get_single(root, "seriesIdentifier"), "series_identifier")
    meta_dict.add(get_single(root, "modality"), "modality")
    meta_dict.add(get_single(root, "dateAcquired"), "date_acquired")
    meta_dict.add(get_single(root, "annotation/text"), "annotation")
    meta_dict.add(get_single(root, "processedDataLabel"), "processed_data_label")
    meta_dict.add(get_single(root, "imageType"), "image_type")
    meta_dict.add(get_single(root, "tissue"), "tissue")
    meta_dict.add(get_single(root, "hemisphere"), "hemisphere")
    meta_dict.add(get_single(root, "anatomicStructure"), "anatomic_structure")
    meta_dict.add(get_single(root, "registration"), "registration")
    meta_dict.add(get_single(root, "creationDate"), "creation_date")
    meta_dict.add(get_single(root, "derivedProduct/imageRating/ratingDescription"), "image_rating_description")
    meta_dict.add(get_single(root, "derivedProduct/imageRating/value"), "image_rating_value")
    meta_dict.add(get_single(root, "originalRelatedImage/description"), "seq_description")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Weighting"), "seq_weighting")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Pulse Sequence"), "seq_pulse")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Slice Thickness"), "seq_slice_thickness")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "TE"), "seq_TE")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "TR"), "seq_TR")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "TI"), "seq_TI")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Coil"), "seq_coil")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Flip Angle"), "seq_flip_angle")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Acquisition Plane"), "seq_acquisition_plane")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Matrix X"), "seq_matrix_x")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Matrix Y"), "seq_matrix_y")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Matrix Z"), "seq_matrix_z")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Pixel Spacing X"), "seq_pixel_spacing_x")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Pixel Spacing Y"), "seq_pixel_spacing_y")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Manufacturer"), "seq_manufacturer")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Mfg Model"), "seq_mfg_model")
    meta_dict.add(get_one_of(root, "protocolTerm/protocol", 'term', "Field Strength"), "seq_field_strength")
    meta_dict.add(get_single(root, "derivedProduct/imageUID"), "derived_image_UID")
    meta_dict.add(get_single(root, "originalRelatedImage/imageUID"), "related_image_UID")

    # Make the final formatting
    meta_dict.finalize()
    return meta_dict.as_data_frame


if __name__ == "__main__":
    data_dir = '/mnt/nvme0n1/ludvig/data/ADNI/'
    include_dirs = ['ADNI-full']
    output_path = data_dir + "processed/meta_data/"
    for d in include_dirs:
        curr_dir = data_dir + d + "/ADNI/"
        meta_file_paths = glob.glob(curr_dir + "*.xml", recursive=False)
        meta_df = pd.concat([read_meta_file(path) for path in meta_file_paths])
        meta_df.to_csv(output_path + d + '_meta.csv')
