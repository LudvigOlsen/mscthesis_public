"""
Presets for training that can be stacked for a more complex training procedure.
"""

import time

from fed_code.training.trainer import Trainer


class TrainingBlock:

    def __init__(self, device, optimizer, loss_fn, test_loss_fn, strategy, num_epochs,
                 args, model_file='network.pt', block_name='base'):
        self.device = device
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.test_loss_fn = test_loss_fn
        self.strategy = strategy
        self.num_epochs = num_epochs
        self.args = args
        self.model_file = model_file
        self.block_name = block_name

    def __call__(self, model, clients, test_clients, start_epoch=0):
        global_epoch = Trainer.train(
            model=model,
            clients=clients,
            test_clients=test_clients,
            strategy=self.strategy,
            device=self.device,
            optimizer=self.optimizer,
            loss_fn=self.loss_fn,
            test_loss_fn=self.test_loss_fn,
            num_epochs=self.num_epochs,
            args=self.args,
            start_epoch=start_epoch
        )

        return global_epoch

    def __str__(self):
        optimizer_string = None
        optimizer_indent = ''
        if self.optimizer is not None:
            optimizer_string = ' '.join(str(self.optimizer).split()).replace(': ', ':').replace('( ', '(').replace(' )', ')')
            optimizer_indent = '\n\t'
        string = (
            f'{self.block_name} | Strategy: {self.strategy} | Num epochs: {self.num_epochs} | '
            f'{optimizer_indent}Optimizer: {optimizer_string}'
        )
        return string


class TrainingCompose:

    def __init__(self, training_blocks=[]):
        """
        :param training_blocks: List of `TrainingBlock`s.
        """
        self.training_blocks = training_blocks

    def __call__(self, model, clients, test_clients, start_epoch=0, skip_to_block=1):
        """
        :param skip_to_block: The block to start at. One-based indexing (first block is 1).
        """
        assert skip_to_block >= 1, '`skip_to_block` is one-based indexed. First block is `1`.'

        global_epoch = start_epoch
        start_time = time.time()
        for block_idx, t_block in enumerate(self.training_blocks):
            if (block_idx+1) < skip_to_block:
                continue
            print(f'TrainingCompose: Starting block {block_idx+1}/{len(self.training_blocks)}.')

            # Start timer for current block
            block_start_time = time.time()

            # Perform training with current block
            global_epoch = t_block(model=model, clients=clients, test_clients=test_clients, start_epoch=global_epoch)

            # Calculate time (block and total)
            block_end_time = time.time()
            block_time = block_end_time - block_start_time
            total_time = block_end_time - start_time

            print(f'TrainingCompose: Finished block {block_idx+1}. Block time: {block_time:.2f}s. Total time: {total_time:.2f}s.')

        return global_epoch

    def __str__(self):
        lines = []
        lines.append('Training pipeline:')
        for tblock in self.training_blocks:
            lines.append(str(tblock))
        return '\n  '.join(lines)


class TestOnlyBlock(TrainingBlock):

    def __init__(self, device, test_loss_fn, args):
        super().__init__(
            device=device,
            optimizer=None,
            loss_fn=None,
            test_loss_fn=test_loss_fn,
            strategy='test_only',
            num_epochs=None,
            args=args,
            model_file=None,
            block_name='TestOnlyBlock'
        )

    def __call__(self, model, clients, test_clients, start_epoch=0):
        return super().__call__(model=model, clients=clients, test_clients=test_clients, start_epoch=start_epoch)


class LocalToConvergenceTrainingBlock(TrainingBlock):

    def __init__(self, device, optimizer, loss_fn, test_loss_fn, num_epochs, args, model_file='network.pt'):
        super().__init__(
            device=device,
            optimizer=optimizer,
            loss_fn=loss_fn,
            test_loss_fn=test_loss_fn,
            strategy='serial_to_convergence',
            num_epochs=num_epochs,
            args=args,
            model_file=model_file,
            block_name='LocalToConvergenceTrainingBlock'
        )

    def __call__(self, model, clients, test_clients, start_epoch=0):
        clients = clients.get_local()
        return super().__call__(model=model, clients=clients, test_clients=test_clients, start_epoch=start_epoch)


class NonLocalsToConvergenceTrainingBlock(TrainingBlock):

    def __init__(self, device, optimizer, loss_fn, test_loss_fn, num_epochs, args, model_file='network.pt'):
        super().__init__(
            device=device,
            optimizer=optimizer,
            loss_fn=loss_fn,
            test_loss_fn=test_loss_fn,
            strategy='serial_to_convergence',
            num_epochs=num_epochs,
            args=args,
            model_file=model_file,
            block_name='NonLocalsToConvergenceTrainingBlock'
        )

    def __call__(self, model, clients, test_clients, start_epoch=0):
        clients = clients.get_nonlocals()
        return super().__call__(model=model, clients=clients, test_clients=test_clients, start_epoch=start_epoch)


class NonLocalsShiftEachEpochTrainingBlock(TrainingBlock):

    def __init__(self, device, optimizer, loss_fn, test_loss_fn, num_epochs, args, model_file='network.pt'):
        super().__init__(
            device=device,
            optimizer=optimizer,
            loss_fn=loss_fn,
            test_loss_fn=test_loss_fn,
            strategy='serial_shift_each_epoch',
            num_epochs=num_epochs,
            args=args,
            model_file=model_file,
            block_name='NonLocalsShiftEachEpochTrainingBlock'
        )

    def __call__(self, model, clients, test_clients, start_epoch=0):
        clients = clients.get_nonlocals()
        return super().__call__(model=model, clients=clients, test_clients=test_clients, start_epoch=start_epoch)


class ParallelTrainingBlock(TrainingBlock):

    def __init__(self, device, optimizer, loss_fn, test_loss_fn, num_epochs, args, train_local, model_file='network.pt'):
        super().__init__(
            device=device,
            optimizer=optimizer,
            loss_fn=loss_fn,
            test_loss_fn=test_loss_fn,
            strategy='parallel',
            num_epochs=num_epochs,
            args=args,
            model_file=model_file,
            block_name='ParallelTrainingBlock'
        )
        self.train_local = train_local

    def __call__(self, model, clients, test_clients, start_epoch=0):
        if not self.train_local:
            clients = clients.get_nonlocals()
        return super().__call__(model=model, clients=clients, test_clients=test_clients, start_epoch=start_epoch)


class SetFinetuningBlock(TrainingBlock):

    def __init__(self, finetune=True):
        """
        Sets finetuning option for pretrained model.
        """
        super().__init__(
            device='',
            optimizer=None,
            loss_fn=None,
            test_loss_fn=None,
            strategy=None,
            num_epochs=None,
            args=None,
            model_file=None,
            block_name='SetFinetuningBlock'
        )
        self.finetune = finetune

    def __call__(self, model, clients, test_clients, start_epoch=0):
        if self.finetune:
            model.enable_finetuning()
        else:
            model.disable_finetuning()
        return start_epoch

    def __str__(self):
        string = (
            f'{self.block_name} | Finetune: {self.finetune}'
        )
        return string
