"""
Context objects are used to store the current context for training/testing, such
as the current epoch and batch.
"""


class TrainingContext:
    def __init__(self, epoch, batch_idx, train_loader, client_name):
        self.epoch = epoch
        self.batch_idx = batch_idx
        self.train_set_size = len(train_loader)
        self.client_name = client_name


class TestContext:
    def __init__(self, epoch, test_loader, client_name):
        self.epoch = epoch
        self.test_set_size = len(test_loader)
        self.client_name = client_name
