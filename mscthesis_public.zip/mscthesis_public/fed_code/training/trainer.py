"""
The training handler.
"""

import os
import copy
import pathlib
from functools import partial

import mlflow
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms

from fed_code.training.context import TrainingContext, TestContext
from fed_code.training.tracking import log_df_artifact
from fed_code.evaluate import MulticlassEvaluator, prepare_multiclass_probabilities
from fed_code.model.model_io import save_checkpoint, load_checkpoint
from fed_code.utils.average_models import average_models, average_optimizers


class Trainer:
    """
    A set of training strategies.
    By having these in the same class,
    it is easy to switch between them in experiments.
    """

    @staticmethod
    def train(model, clients, test_clients, strategy, device, optimizer, loss_fn, test_loss_fn, num_epochs, args, start_epoch=0):
        """
        :param test_clients: The clients to test on after each round (e.g. epoch or client convergence).
        """
        training_funcs = {
            'serial_shift_each_epoch': Trainer._train_serially_shift_each_epoch,
            'serial_to_convergence': Trainer._train_serially_to_convergence,
            'parallel': Trainer._train_parallel,
            'test_only': Trainer._test_only
        }
        train_fn = training_funcs[strategy]
        global_epoch = train_fn(
            model=model,
            clients=clients,
            test_clients=test_clients,
            device=device,
            optimizer=optimizer,
            loss_fn=loss_fn,
            test_loss_fn=test_loss_fn,
            num_epochs=num_epochs,
            args=args,
            start_epoch=start_epoch
        )

        return global_epoch

    @staticmethod
    def test(model, clients, device, test_loss_fn, args, step, save=False, log_result=True, exclude_clients=[]):
        evaluations = {}
        ova_evaluations = {}
        preds = {}
        for client in clients:
            if client.name in exclude_clients:
                continue
            test_loader = client.test_data.get_data_loader(batch_size=args.batch_size, n_workers=args.n_workers, sample=False)
            client_evaluation, client_ova_evaluations, client_prediction_df = Trainer._test(
                model=model,
                test_loader=test_loader,
                test_loss_fn=test_loss_fn,
                device=device,
                args=args)
            # Add client name and step to data frames
            # And add data frames to collections
            add_test_info = partial(Trainer._add_test_info_to_df, client_name=client.name, step=step)
            evaluations[client.name] = add_test_info(df=client_evaluation)
            ova_evaluations[client.name] = add_test_info(df=client_ova_evaluations)
            preds[client.name] = add_test_info(df=client_prediction_df)

        if log_result:
            Trainer._print_epoch_test_summary(evaluations=evaluations)

        if save:
            Trainer._log_evaluations(
                path=args.save_path,
                step=step,
                evaluations=evaluations,
                one_vs_all_evaluations=ova_evaluations,
                predictions=preds)

        return evaluations, ova_evaluations, preds

    @staticmethod
    def _add_test_info_to_df(df, client_name, step):
        df['Client'] = client_name
        df['Step'] = step
        return df

    @staticmethod
    def _train_serially_shift_each_epoch(model, clients, test_clients, device, optimizer, loss_fn,
                                         test_loss_fn, num_epochs, args, start_epoch=0):
        """
        :param clients: ...
        """

        global_epoch = start_epoch
        for _ in range(num_epochs):
            for _, client in enumerate(clients):
                global_epoch += 1
                Trainer._train_epoch(
                    model=model,
                    client=client,
                    device=device,
                    optimizer=optimizer,
                    loss_fn=loss_fn,
                    test_loss_fn=test_loss_fn,
                    args=args,
                    epoch=global_epoch
                )

            # Test on the test clients (except current client as we already did that)
            Trainer.test(model=model, clients=test_clients, test_loss_fn=test_loss_fn, device=device,
                         args=args, step=global_epoch, save=True)

        return global_epoch

    @staticmethod
    def _train_serially_to_convergence(model, clients, test_clients, device, optimizer, loss_fn,
                                       test_loss_fn, num_epochs, args, start_epoch=0):
        """
        :param clients: ...
        """
        global_epoch = start_epoch
        block_best_bal_acc = 0.0
        all_checkpoint_paths = []
        for _, client in enumerate(clients):
            client_best_bal_acc = 0.0
            for _ in range(num_epochs):  # TODO We need some early-stopping infrastructure
                global_epoch += 1
                test_evaluation = Trainer._train_epoch(
                    model=model,
                    client=client,
                    device=device,
                    optimizer=optimizer,
                    loss_fn=loss_fn,
                    test_loss_fn=test_loss_fn,
                    args=args,
                    epoch=global_epoch
                )

                # Save checkpoint if better than previous model
                balanced_accuracy = test_evaluation['Balanced Accuracy'][0]
                if balanced_accuracy > client_best_bal_acc:
                    client_best_bal_acc = balanced_accuracy
                    client_best_checkpoint_path = save_checkpoint(network_state=model.state_dict(), optimizer_state=optimizer.state_dict(),
                                                                  checkpoint_dir=args.save_path / 'checkpoint', epoch=global_epoch, client=client.name)
                    all_checkpoint_paths.append(client_best_checkpoint_path)

            # Load best model for this client
            model, optimizer = load_checkpoint(model=model, optimizer=optimizer, checkpoint_path=client_best_checkpoint_path)

            # Test on the test clients
            evaluations, _, _ = Trainer.test(model=model, clients=test_clients, test_loss_fn=test_loss_fn,
                                             device=device, args=args, step=global_epoch, save=True)

            # We use the local dataset as benchmark for all clients
            local_balanced_accuracy = evaluations['local']['Balanced Accuracy'][0]
            if local_balanced_accuracy > block_best_bal_acc:
                block_best_bal_acc = local_balanced_accuracy
                block_best_checkpoint_path = client_best_checkpoint_path

        # Load best model from all client
        print(f'Loading checkpoint for best model in block: {block_best_checkpoint_path.name}')
        model, optimizer = load_checkpoint(model=model, optimizer=optimizer, checkpoint_path=block_best_checkpoint_path)

        # Checkpoints to delete
        checkpoint_paths_to_delete = [p for p in all_checkpoint_paths if p != block_best_checkpoint_path]

        # Delete the unused (not best in block) checkpoints
        for path in checkpoint_paths_to_delete:
            try:
                path.unlink()
            except Exception as exc:
                print(f'Could not delete this checkpoint: {path} - {exc}')

        return global_epoch

    @staticmethod
    def _train_parallel(model, clients, test_clients, device, optimizer, loss_fn,
                        test_loss_fn, num_epochs, args, start_epoch=0):
        """
        :param clients: ...
        """
        global_epoch = start_epoch
        block_best_bal_acc = 0.0
        all_checkpoint_paths = []
        for _ in range(num_epochs):
            global_epoch += 1
            # To calculate the improvement, we need an initial evaluation
            initial_test_evaluations, _, _ = Trainer.test(
                model=model, clients=clients, device=device, test_loss_fn=test_loss_fn,
                args=args, step=global_epoch, save=False, log_result=False)

            # Initialize collections for client models, optimizer
            # and improvements in balanced accuracy
            models = []
            optimizers = []
            improvements_test_loss = []
            # Train each client's model
            for _, client in enumerate(clients):
                client_model = copy.deepcopy(model)
                client_optimizer = copy.deepcopy(optimizer)
                client_test_evaluation = Trainer._train_epoch(
                    model=client_model,
                    client=client,
                    device=device,
                    optimizer=client_optimizer,
                    loss_fn=loss_fn,
                    test_loss_fn=test_loss_fn,
                    args=args,
                    epoch=global_epoch,
                    log_result=False
                )
                models.append(client_model)
                optimizers.append(client_optimizer)

                # Calculate improvement on client's test set
                client_test_loss_pre = initial_test_evaluations[client.name]['Loss'][0]
                client_test_loss_post = client_test_evaluation['Loss'][0]
                improvement_test_loss = max(0.0, client_test_loss_pre - client_test_loss_post)
                improvements_test_loss.append(improvement_test_loss)

            # Calculate total improvement
            total_improvement = sum(improvements_test_loss)
            num_clients_improved = sum([imp > 0 for imp in improvements_test_loss])
            print(f'Epoch {global_epoch}: Total improvement across clients: {total_improvement}. {num_clients_improved} clients improved.')

            # If improvements were made, average the models
            if total_improvement > 1e-10:
                improved_weight_multiplier = 5000
                normalization_denominator = (total_improvement * improved_weight_multiplier + len(improvements_test_loss))
                weights = [(1 + imp * improved_weight_multiplier) / normalization_denominator for imp in improvements_test_loss]
                model = average_models(models, weights=weights, out_model=model)
                optimizer = average_optimizers(optimizers, weights=weights, out_optimizer=optimizer)

                test_evaluations, _, _ = Trainer.test(
                    model=model, clients=test_clients, device=device, test_loss_fn=test_loss_fn,
                    args=args, step=global_epoch, save=True)

                # Save checkpoint if better than previous model
                local_balanced_accuracy = test_evaluations['local']['Balanced Accuracy'][0]
                if local_balanced_accuracy > block_best_bal_acc:
                    block_best_bal_acc = local_balanced_accuracy
                    block_best_checkpoint_path = save_checkpoint(
                        network_state=model.state_dict(), optimizer_state=optimizer.state_dict(),
                        checkpoint_dir=args.save_path / 'checkpoint', epoch=global_epoch, client='Averaged')
                    all_checkpoint_paths.append(block_best_checkpoint_path)

        # Load best model from all client
        print(f'Loading checkpoint for best model in block: {block_best_checkpoint_path.name}')
        model, optimizer = load_checkpoint(model=model, optimizer=optimizer, checkpoint_path=block_best_checkpoint_path)

        # Checkpoints to delete
        checkpoint_paths_to_delete = [p for p in all_checkpoint_paths if p != block_best_checkpoint_path]

        # Delete the unused (not best in block) checkpoints
        for path in checkpoint_paths_to_delete:
            try:
                path.unlink()
            except Exception as exc:
                print(f'Could not delete this checkpoint: {path} - {exc}')

        return global_epoch

    @staticmethod
    def _test_only(model, clients, test_clients, device, optimizer, loss_fn, test_loss_fn, num_epochs, args, start_epoch=0):
        """
        Has same interface as other training strategy methods, but only calls test method.
        This allows easy use in `TrainingCompose`.
        :param clients: ...
        """
        # Test on the test clients (except current client as we already did that)
        Trainer.test(model=model, clients=test_clients, test_loss_fn=test_loss_fn, device=device,
                     args=args, step=start_epoch, save=True)

        return start_epoch

    @staticmethod
    def _train_epoch(model, client, device, optimizer, loss_fn, test_loss_fn, args, epoch, log_result=True):
        # Enable training mode
        model.train()

        # Get data loaders
        train_loader = client.training_data.get_data_loader(batch_size=args.batch_size, n_workers=args.n_workers, sample=True)
        test_loader = client.test_data.get_data_loader(batch_size=args.batch_size, n_workers=args.n_workers, sample=False)

        # Train the model on the client

        train_losses = []

        for batch_idx, batch in enumerate(train_loader):
            train_context = TrainingContext(epoch=epoch, batch_idx=batch_idx, train_loader=train_loader,
                                            client_name=client.name)
            train_loss = Trainer._train_batch(
                model=model,
                batch=batch,
                device=device,
                optimizer=optimizer,
                loss_fn=loss_fn,
                args=args
            )
            train_losses.append(train_loss)

            # Log progress
            Trainer._print_rolling_batch_summary(args=args, context=train_context, rolling_loss=sum(train_losses) / len(train_losses))

        # Get average training loss (i.e. average loss at a single data point)
        train_loss = sum(train_losses) / len(train_losses)
        mlflow.log_metric(f'{client.name}_train_loss', train_loss, step=epoch)

        # Test model on client's test set
        test_context = TestContext(epoch=epoch, test_loader=test_loader, client_name=client.name)
        test_evaluation, test_ova_evaluations, _ = Trainer._test(model=model, test_loader=test_loader, test_loss_fn=test_loss_fn,
                                                                 device=device, args=args)
        if log_result:
            MulticlassEvaluator.log_evaluations(evaluation=test_evaluation, ova_evaluations=test_ova_evaluations,
                                                dataset_name=client.name, step=epoch)
            Trainer._print_epoch_summary(context=test_context, train_loss=train_loss, test_eval=test_evaluation)

        return test_evaluation

    @staticmethod
    def _train_batch(model, batch, device, optimizer, loss_fn, args):
        data = batch['data']
        label = batch['label_idx']

        data, label, model = data.to(device), label.to(device), model.to(device)
        optimizer.zero_grad()
        output = model(data)

        # Get pointer to loss tensor at remote location
        loss = loss_fn(output, label)

        # Ask remote to call backward() on the loss pointer
        loss.backward()

        # Update network
        optimizer.step()

        # Return average loss
        return (loss / len(label)).item()

    @staticmethod
    def _test(model, test_loader, test_loss_fn, device, args):

        model.eval()
        test_loss = 0
        outputs = []
        labels = []

        for _, batch in enumerate(test_loader):
            batch_output, batch_labels, batch_test_loss = Trainer._test_batch(
                model=model,
                batch=batch,
                test_loss_fn=test_loss_fn,
                device=device
            )
            test_loss += batch_test_loss
            outputs.append(batch_output.cpu().numpy())
            labels.append(batch_labels.cpu().numpy())

        predicted_probabilities = np.concatenate(outputs)
        labels = np.concatenate(labels).flatten()
        prediction_df = prepare_multiclass_probabilities(
            targets=labels,
            probabilities=predicted_probabilities,
            num_classes=args.num_classes,
            target_idx_to_label=args.label_idx_to_name_dict
        )

        # Evaluate predictions
        evaluation, one_vs_all_evaluations = MulticlassEvaluator.evaluate(
            targets=prediction_df['target'],
            predictions=prediction_df['prediction'],
            num_classes=args.num_classes
        )

        # Average test loss
        test_loss /= len(test_loader.dataset)
        evaluation['Loss'] = test_loss

        return evaluation, one_vs_all_evaluations, prediction_df

    @staticmethod
    def _test_batch(model, batch, test_loss_fn, device):
        data = batch['data']
        label = batch['label_idx']

        with torch.no_grad():
            # Send tensors to device
            data, label, model = data.to(device), label.to(device), model.to(device)
            output = model(data)
            test_loss = test_loss_fn(output, label, reduction='sum').item()  # Sum up batch loss

        return output, label, test_loss

    @staticmethod
    def _log_evaluations(path, step, evaluations, one_vs_all_evaluations, predictions):
        """
        :param path: pathlib.Path to output folder.
        :param evaluations: dict mapping `client->evaluation`
        """
        end_string = f'_step_{step}.csv'
        if not path.is_dir():
            raise ValueError(f'`path` is not existing directory: {path}')

        for client_name in evaluations.keys():
            MulticlassEvaluator.log_evaluations(
                evaluation=evaluations[client_name],
                ova_evaluations=one_vs_all_evaluations[client_name],
                dataset_name=client_name,
                step=step
            )

        # Convert to data frames and write to desk and log to mlflow
        log_df_artifact(pd.concat(evaluations.values()), path / ('evaluations' + end_string))
        log_df_artifact(pd.concat(one_vs_all_evaluations.values()), path / ('ova_evaluations' + end_string))
        log_df_artifact(pd.concat(predictions.values()), path / ('predictions' + end_string))

    @staticmethod
    def _print_rolling_batch_summary(args, context, rolling_loss):
        if context.batch_idx % args.log_interval == 0:
            print('Training at {} | Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                context.client_name,
                context.epoch,
                context.batch_idx * args.batch_size,
                context.train_set_size * args.batch_size,
                100. * context.batch_idx / context.train_set_size,
                rolling_loss), end='\r')

    @staticmethod
    def _print_epoch_summary(context, train_loss, test_eval):
        test_eval = test_eval.to_dict('records')[0]
        print('At {} | Epoch: {}\tTrain Loss: {:.6f}\tTest Loss: {:.6f}\tTest OAcc: {:.6f}\tTest BAcc: {:.6f}'.format(
            context.client_name,
            context.epoch,
            train_loss,
            test_eval['Loss'],
            test_eval['Overall Accuracy'],
            test_eval['Balanced Accuracy']
        ))

    @staticmethod
    def _print_epoch_test_summary(evaluations):
        print(f'Testing on clients:')
        for client_name in evaluations.keys():
            # Extract client evaluation as a dict
            # Expect evaluation df to have only 1 row
            client_eval = evaluations[client_name].to_dict('records')[0]
            print(f'Testing at {client_name}: Test loss: {client_eval["Loss"]:.5f}. '
                  f'Test overall accuracy: {client_eval["Overall Accuracy"]:.3f}. '
                  f'Test balanced accuracy: {client_eval["Balanced Accuracy"]:.3f}.'
                  )
