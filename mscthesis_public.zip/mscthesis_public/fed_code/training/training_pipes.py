
import fed_code.training.training_blocks as tblocks


class PipelineCollection:

    def __init__(self, device, hparams, loss_fn, test_loss_fn,
                 optimizer_finetune, optimizer_no_finetune
                 ):
        self.device = device
        self.hparams = hparams
        self.loss_fn = loss_fn
        self.test_loss_fn = test_loss_fn
        self.optimizer_finetune = optimizer_finetune
        self.optimizer_no_finetune = optimizer_no_finetune

    def _test_only_block(self):
        return tblocks.TestOnlyBlock(device=self.device, test_loss_fn=self.test_loss_fn, args=self.hparams)

    def _local_to_convergence_block(self, finetune):
        if finetune:
            return tblocks.LocalToConvergenceTrainingBlock(
                device=self.device, optimizer=self.optimizer_finetune, loss_fn=self.loss_fn,
                test_loss_fn=self.test_loss_fn, num_epochs=self.hparams.epochs_finetune, args=self.hparams)
        else:
            return tblocks.LocalToConvergenceTrainingBlock(
                device=self.device, optimizer=self.optimizer_no_finetune, loss_fn=self.loss_fn,
                test_loss_fn=self.test_loss_fn, num_epochs=self.hparams.epochs_no_finetune, args=self.hparams)

    def _parallel_block(self, finetune, train_local):
        if finetune:
            return tblocks.ParallelTrainingBlock(
                device=self.device, optimizer=self.optimizer_finetune, loss_fn=self.loss_fn,
                test_loss_fn=self.test_loss_fn, num_epochs=self.hparams.epochs_finetune, args=self.hparams,
                train_local=train_local)
        else:
            return tblocks.ParallelTrainingBlock(
                device=self.device, optimizer=self.optimizer_no_finetune, loss_fn=self.loss_fn,
                test_loss_fn=self.test_loss_fn, num_epochs=self.hparams.epochs_no_finetune, args=self.hparams,
                train_local=train_local)

    def local_only(self, finetune):
        if finetune:
            # First n epochs are without finetuning
            return tblocks.TrainingCompose([
                self._test_only_block(),
                tblocks.SetFinetuningBlock(finetune=False),
                self._local_to_convergence_block(finetune=False),
                self._test_only_block(),
                tblocks.SetFinetuningBlock(finetune=True),
                self._local_to_convergence_block(finetune=True),
                self._test_only_block(),
            ])
        else:
            return tblocks.TrainingCompose([
                self._test_only_block(),
                self._local_to_convergence_block(finetune=False),
                self._test_only_block(),
            ])

    def parallel(self, finetune, train_local=True):
        if finetune:
            # First n epochs are without finetuning
            return tblocks.TrainingCompose([
                self._test_only_block(),
                tblocks.SetFinetuningBlock(finetune=False),
                self._parallel_block(finetune=False, train_local=train_local),
                self._test_only_block(),
                tblocks.SetFinetuningBlock(finetune=True),
                self._parallel_block(finetune=True, train_local=train_local),
                self._test_only_block(),
            ])
        else:
            return tblocks.TrainingCompose([
                self._test_only_block(),
                self._parallel_block(finetune=False, train_local=train_local),
                self._test_only_block(),
            ])

    def test_all(self):
        return tblocks.TrainingCompose([
            self._test_only_block()
        ])
