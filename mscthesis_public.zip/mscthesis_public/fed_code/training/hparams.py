
import mlflow

class HParams():
    def __init__(self, batch_size, test_batch_size, epochs_finetune, epochs_no_finetune,
                 label_name_to_idx_dict, finetune, lr_finetune, lr_no_finetune,
                 momentum, weight_decay, pretrained,
                 use_cuda, n_workers, save_path, log_interval=30, save_model=False,
                 dropout_prob = 0.2,
                 aug_center_crop_size = (60, 3, 224, 224),
                 aug_max_offset=0.25,
                 aug_max_amount_robust_gaussian=0.03,
                 aug_max_amount_salt_pepper=0.03,
                 aug_max_translate_xy=[15, 15],
                 aug_prob_depth_flip=0.5,
                 aug_prob_horizontal_flip=0.5,
                 aug_prob_vertical_flip=0.5
                 ):
        self.batch_size = batch_size
        self.test_batch_size = test_batch_size
        self.epochs_finetune = epochs_finetune
        self.epochs_no_finetune = epochs_no_finetune
        self.label_name_to_idx_dict = label_name_to_idx_dict
        self.label_idx_to_name_dict = {idx: key for key, idx in label_name_to_idx_dict.items()}
        self.num_classes = len(label_name_to_idx_dict)
        self.finetune = finetune
        self.lr_finetune = lr_finetune
        self.lr_no_finetune = lr_no_finetune
        self.momentum = momentum
        self.weight_decay = weight_decay
        self.pretrained = pretrained
        self.use_cuda = use_cuda
        self.n_workers = n_workers
        self.save_path = save_path
        self.log_interval = log_interval
        self.save_model = save_model

        self.dropout_prob = dropout_prob
        self.aug_center_crop_size = aug_center_crop_size
        self.aug_max_offset = aug_max_offset
        self.aug_max_amount_robust_gaussian = aug_max_amount_robust_gaussian
        self.aug_max_amount_salt_pepper = aug_max_amount_salt_pepper
        self.aug_max_translate_xy = aug_max_translate_xy
        self.aug_prob_depth_flip = aug_prob_depth_flip
        self.aug_prob_horizontal_flip = aug_prob_horizontal_flip
        self.aug_prob_vertical_flip = aug_prob_vertical_flip

    def log_params(self):
        for key, val in self.__dict__.items():
            mlflow.log_param(key, val)
