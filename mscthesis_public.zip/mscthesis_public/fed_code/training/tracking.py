
import mlflow

def log_string_artifact(x, path, mode='w'):
    with open(path, mode) as text_file:
        text_file.write(x)
    mlflow.log_artifact(str(path))


def log_df_artifact(x, path):
    x.to_csv(path)
    mlflow.log_artifact(str(path))
