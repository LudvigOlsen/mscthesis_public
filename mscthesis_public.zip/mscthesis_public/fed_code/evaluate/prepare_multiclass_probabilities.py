
import pandas as pd
import numpy as np


def prepare_multiclass_probabilities(targets, probabilities, num_classes, target_idx_to_label):
    # Get predicted class (index of highest probability)
    predicted_classes = np.argmax(probabilities, axis=1)

    # Create data frame
    predictions_df = pd.DataFrame({
        'target': targets,
        'prediction': predicted_classes,
        'target_label': [target_idx_to_label[targ] for targ in targets],
        'prediction_label': [target_idx_to_label[pred] for pred in predicted_classes],
    })

    labels = [target_idx_to_label[cl] for cl in range(num_classes)]
    probabilities_df = pd.DataFrame(probabilities, columns=labels)
    predictions_df = pd.concat([predictions_df, probabilities_df], axis=1)
    return predictions_df
