
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix


class BinaryEvaluator:

    @staticmethod
    def evaluate(targets, predictions):
        return BinaryEvaluator()(targets=targets, predictions=predictions)

    def __call__(self, targets, predictions):
        """
        :param predictions: List of class predictions (int).
        """
        conf_mat = confusion_matrix(targets, predictions)
        return BinaryEvaluator._evaluate_binary_clf(conf_mat=conf_mat)

    @staticmethod
    def _evaluate_binary_clf(conf_mat):
        tn, fp, fn, tp = conf_mat.ravel()
        total = sum([tn, fp, fn, tp])
        recall = sensitivity = safe_div(tp, tp + fn)
        specificity = safe_div(tn, tn + fp)
        precision = safe_div(tp, tp + fp)
        npv = safe_div(tn, tn + fn)
        f1 = 2 * safe_div(precision * recall, precision + recall)
        accuracy = safe_div(tn + tp, total)
        balanced_accuracy = (sensitivity + specificity) / 2
        return pd.DataFrame({"Accuracy": [accuracy],
                             "Balanced Accuracy": [balanced_accuracy],
                             "F1": [f1],
                             "Sensitivity": [sensitivity],
                             "Specificity": [specificity],
                             "PPV": [precision],
                             "NPV": [npv],
                             "TP": [tp],
                             "FP": [fp],
                             "TN": [tn],
                             "FN": [fn],
                             "Num Classes": 2})


def safe_div(x, y):
    if y == 0:
        return np.nan
    else:
        return x / y
