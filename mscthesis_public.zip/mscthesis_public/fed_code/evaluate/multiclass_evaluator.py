
import pandas as pd
import mlflow

from fed_code.evaluate.binary_evaluator import BinaryEvaluator


class MulticlassEvaluator:

    MACRO_METRICS = ["Accuracy", "Balanced Accuracy", "F1", "Sensitivity", "Specificity", "PPV", "NPV"]
    ALL_METRICS = MACRO_METRICS + ['Overall Accuracy', 'Num Classes']

    @staticmethod
    def evaluate(targets, predictions, num_classes):
        return MulticlassEvaluator()(targets=targets, predictions=predictions, num_classes=num_classes)

    def __call__(self, targets, predictions, num_classes):
        # Perform the one-vs-all binary evaluations
        one_vs_all_evals = MulticlassEvaluator._evaluate_one_vs_all(targets, predictions, num_classes)

        # Macro evaluation (averaging)
        macro_eval = one_vs_all_evals[MulticlassEvaluator.MACRO_METRICS].mean(axis=0)
        macro_eval = pd.DataFrame(macro_eval).T

        # Overall evaluation
        overall_accuracy = sum(targets == predictions) / len(targets)

        # Combine to multiclass evaluation
        mc_eval = macro_eval
        mc_eval['Overall Accuracy'] = overall_accuracy
        mc_eval['Num Classes'] = num_classes

        return mc_eval, one_vs_all_evals

    @staticmethod
    def _evaluate_one_vs_all(targets, predictions, num_classes):
        evaluator = BinaryEvaluator()
        one_vs_all_evals = []
        for cl in range(num_classes):
            ova_targets = [int(t == cl) for t in targets]
            ova_predictions = [int(p == cl) for p in predictions]
            class_eval = evaluator(targets=ova_targets, predictions=ova_predictions)
            class_eval['Class'] = cl
            one_vs_all_evals.append(class_eval)
        one_vs_all_evals = pd.concat(one_vs_all_evals)
        return one_vs_all_evals

    @staticmethod
    def log_evaluations(evaluation=None, ova_evaluations=None, dataset_name=None, step=None):
        assert dataset_name is not None

        def format_metric_name(metric, prefix):
            return prefix + metric.lower().replace(' ', '_')

        # Log evaluation
        if evaluation is not None:
            assert len(evaluation) == 1, '`evaluation` is expected to have one row.'
            prefix = f'{dataset_name}_'
            eval_as_dict = evaluation.to_dict('records')[0]
            for key,val in eval_as_dict.items():
                if key in ['Client']:
                    continue
                metric_name = format_metric_name(key, prefix)
                mlflow.log_metric(metric_name, val, step=step)

        # Log one-vs-all
        if ova_evaluations is not None:
            eval_as_dicts = ova_evaluations.to_dict('records')
            for eval_dict in eval_as_dicts:
                cl = eval_dict['Class']
                prefix = f'OVA_{dataset_name}_{cl}_'
                for metric, val in eval_dict.items():
                    if metric in ['Class', 'Client']:
                        continue
                    metric_name = format_metric_name(metric, prefix)
                    mlflow.log_metric(metric_name, val, step=step)
