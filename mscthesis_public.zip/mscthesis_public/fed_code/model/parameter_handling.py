

def set_requires_grad(model, value):
    for param in model.parameters():
        param.requires_grad = value


def get_optim_params(model, requires_grad_only=True):
    """
    Get parameters to optimize.
    """
    if not requires_grad_only:
        return model.parameters()
    params_to_update = []
    for _, param in model.named_parameters():
        if param.requires_grad == True:
            params_to_update.append(param)
    return params_to_update
