"""
This module contains functions to export and import pytorch models.
Inspired by Cercare Medical's model import/export functions.
"""

import os
import torch


def export_model(network_state, architecture, n_classes, inference_transform, model_dir, architecture_kwargs=None):
    """
    Export model to 'model_dir'.

    :param network_state: state_dict (model weights and biases) to be saved.
    :param architecture: Model architecture to be saved (an instance of torch.nn.Module).
    :param n_classes: Number of classes in model.
    :param inference_transforms: Pre-processing transformations to perform before applying the model.
    :param model_dir: Path to directory where model will be saved. Must already exist.
    :param architecture_kwargs: Dict of additional arguments to pass to the initiation of the architecture.
    :return: None
    """

    if architecture_kwargs is None:
        architecture_kwargs = {}

    model_output_file = model_dir / 'model.pth'
    model_dict = {'network_state': network_state,
                  'architecture': architecture,
                  'n_classes': n_classes,
                  'inference_transform': inference_transform,
                  'architecture_kwargs': architecture_kwargs,
                  }

    # Create dir if necessary
    os.makedirs(model_dir, exist_ok=True)

    # Save model
    torch.save(model_dict, model_output_file)


def import_model(model_dir):
    """
    Import model from 'model_dir'

    :param model_dir: Path to directory where model will be loaded from
    :return: A tuple containing,
        - The loaded model
        - Number of classes in output layer
        - Pre-processing transformations to perform before applying the model
        - The model architecture class
    """
    model_output_file = model_dir / 'model.pth'

    model_dict = torch.load(model_output_file, map_location=torch.device('cpu'))
    architecture = model_dict['architecture']
    n_classes = model_dict['n_classes']
    architecture_kwargs = model_dict['architecture_kwargs']
    model = architecture(n_classes, **architecture_kwargs)
    model.load_state_dict(model_dict['network_state'])
    inference_transform = model_dict['inference_transform']

    return model, n_classes, inference_transform, architecture


def save_checkpoint(network_state, optimizer_state, checkpoint_dir, epoch, client):
    """
    Checkpoint model and optimizer states to 'checkpoint_dir'.

    :param network_state: model's state_dict (model weights and biases) to be saved.
    :param optimizer_state: optimizer's state_dict to be save.
    :param checkpoint_dir: Path to directory where model will be saved.
    :param epoch: The current epoch.
    :param client: The client currently being trained on.
    :return: Path to checkpoint.
    """

    checkpoint_output_file = checkpoint_dir / f'ckpt_{epoch}.pth'
    checkpoint_dict = {'network_state': network_state,
                       'optimizer_state': optimizer_state,
                       'epoch': epoch,
                       'client': client
                       }

    # Create dir if necessary
    os.makedirs(checkpoint_dir, exist_ok=True)

    # Save model
    torch.save(checkpoint_dict, checkpoint_output_file)

    return checkpoint_output_file


def load_checkpoint(model, optimizer, checkpoint_path):
    """
    Load a saved checkpoint.

    :param model: A model instance to load state into.
    :param optimizer: An optimizer to load state into.
    :checkpoint_path: Path to saved checkpoint to load.
    :return: `model` and `optimizer` with altered states.
    """
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['network_state'])
    optimizer.load_state_dict(checkpoint['optimizer_state'])
    return model, optimizer
