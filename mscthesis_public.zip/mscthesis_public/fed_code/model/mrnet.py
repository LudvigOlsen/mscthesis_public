"""
Inspired by:
https://medium.datadriveninvestor.com/deep-learning-and-medical-imaging-how-to-provide-an-automatic-diagnosis-f0138ea824d
https://github.com/ahmedbesbes/mrnet

NOTE: Whereas this network ran fine, it didn't actually learn anything 
(below-chance balanced accuracy) on my task.
"""

import torch
import torch.nn as nn
from torchvision import models

from fed_code.model.parameter_handling import set_requires_grad


class MRNet(nn.Module):
    def __init__(self, network_name='alexnet', num_classes=3, finetune=False, dropout_prob=0.2):
        """
        :param finetune: Whether to finetune pretrained model.
            When disabled, the pretrained model is used for feature extraction only.
        """
        super().__init__()
        self.network_name = network_name
        self.num_classes = num_classes
        self.finetune = finetune
        self.dropout_prob = dropout_prob

    def forward(self, x):
        # Remove batch dimension
        # so slice dim is the batch dim
        x = torch.squeeze(x, dim=0)
        return x

    def enable_finetuning(self):
        set_requires_grad(self.pretrained_model, True)
        self.finetune = True

    def disable_finetuning(self):
        set_requires_grad(self.pretrained_model, False)
        self.finetune = False

    def create_classifier(self, in_features):
        return nn.Sequential(
            nn.Dropout(p=self.dropout_prob),
            nn.Linear(in_features, int(in_features / 2)),
            nn.ReLU(),
            nn.Dropout(p=self.dropout_prob),
            nn.Linear(int(in_features / 2), self.num_classes)
        )


class MRNetAlexNet(MRNet):

    def __init__(self, num_classes=3, finetune=False, dropout_prob=0.2):
        super().__init__(network_name='alexnet', num_classes=num_classes,
                         finetune=finetune, dropout_prob=dropout_prob)
        self.pretrained_model = models.alexnet(pretrained=True)
        self.features = self.pretrained_model.features
        self.pooling_layer = PoolAndFlatten(1)
        self.classifier = self.create_classifier(256)

        # Set finetuning
        if not finetune:
            self.disable_finetuning()

    def forward(self, x):
        # Remove batch dimension
        # so slice dim is the batch dim
        x = super().forward(x)
        # Extract features
        features = self.features(x)
        pooled_features = self.pooling_layer(features)
        output = self.classifier(pooled_features)
        return output


class MRNetResNet50(MRNet):

    def __init__(self, num_classes=3, finetune=False, dropout_prob=0.2):
        super().__init__(network_name='resnet50', num_classes=num_classes,
                         finetune=finetune, dropout_prob=dropout_prob)
        self.pretrained_model = models.resnet50(pretrained=True)
        self.pretrained_model.avgpool = PoolAndFlatten(1)
        self.pretrained_model.fc = self.create_classifier(2048)

        # Set finetuning
        if not finetune:
            self.disable_finetuning()

    def forward(self, x):
        # Remove batch dimension
        # so slice dim is the batch dim
        x = super().forward(x)
        # Extract features
        output = self.pretrained_model(x)
        return output

    def disable_finetuning(self):
        set_requires_grad(self.pretrained_model, False)
        # The fc layer should always be updated
        set_requires_grad(self.pretrained_model.fc, True)
        self.finetune = False


class PoolAndFlatten(nn.AdaptiveAvgPool2d):

    def forward(self, features):
        pooled_features = super().forward(features)
        pooled_features = pooled_features.view(pooled_features.size(0), -1)
        flattened_features = torch.max(pooled_features, 0, keepdim=True)[0]
        return flattened_features
