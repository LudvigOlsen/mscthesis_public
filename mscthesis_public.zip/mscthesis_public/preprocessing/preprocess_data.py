"""
This script reads in the "raw" .nii.gz files, preprocesses them and saves them.
"""

import argparse
import pathlib
import ants
import antspynet
import SimpleITK as sitk
import numpy as np


def read_prep_save_image(input_file, output_dir):
    """
    Reads a nifti file, preprocesses it, and save it and the extracted brain mask.
    """
    assert isinstance(input_file, str)
    assert isinstance(output_dir, str)

    # Read and preprocess image
    try:
        img, brain = read_preprocess_image(path=input_file)
    except Exception as e:
        print('Could not read/preprocess this file: ', str(input_file), '. Exception: ', str(e))
        return

    # Get session name
    session = pathlib.Path(input_file).parents[1].name

    # Create path to save images to
    img_out = pathlib.Path(output_dir) / session / 't1w.nii.gz'
    brain_out = pathlib.Path(output_dir) / session / 'brain.nii.gz'

    # Save preprocessed image
    try:
        save_image(img=img, path=str(img_out))
    except Exception as e:
        print('Failed to save preprocessed image. Exception: ', str(e))
        return

    # Save brain mask
    try:
        save_image(img=brain, path=str(brain_out))
    except Exception as e:
        print('Failed to save extracted brain mask. Exception: ', str(e))


def save_image(img, path):
    """
    Save image to path.
    """
    assert isinstance(path, str)
    assert path[-7:] == '.nii.gz', 'path must have `.nii.gz` extension.'
    # Create parent folders
    pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
    # Write image
    ants.image_write(img, path)


def read_preprocess_image(path):
    """
    Read and preprocess a nifti file.
    The image is resampled to a 2x1x1 spacing.
    The brain masked is extracted and applied to the image.
    The brain is standardized (centered and scaled).

    :return: Preprocessed image and brain mask. Both as ants images.
    """

    assert isinstance(path, str)

    # Read in the image as SimpleITK image
    t1_img = sitk.ReadImage(path, sitk.sitkFloat32)

    # Resample to common spacing
    resampled_t1_img = resample_img(t1_img, out_spacing=[2.0, 1.0, 1.0])

    # Crop around center (70 slices, 224 x 224 px)
    # Gives us the same dims for all images
    # and removes empty space
    cropped_t1_image = center_crop(resampled_t1_img, (70, 224, 224))

    # Convert to ants image
    t1_ants = sitk_to_ants(cropped_t1_image)

    # Extract brain mask
    brain_mask = antspynet.brain_extraction(t1_ants, modality='t1', verbose=False)

    # Apply brain mask to t1 image
    t1_ants_masked = ants.mask_image(t1_ants.copy(), brain_mask)

    # Normalize (center + scale)
    t1_standardized = standardize_masked(arr=t1_ants_masked.numpy(), mask=brain_mask.numpy())
    t1_ants_standardized = t1_ants_masked.new_image_like(t1_standardized)

    return t1_ants_standardized, brain_mask


def sitk_to_ants(img):
    """
    Convert a SimpleITK image to an ants image.
    """
    # Convert to numpy array
    # Note that GetArray.. transposes the dimension order,
    # so we transpose it back!
    img_numpy = sitk.GetArrayFromImage(img).transpose()

    # Extract direction and convert to ndims x ndims matrix
    direction = img.GetDirection()
    num_dims = int(np.sqrt(len(direction)))
    direction = np.reshape(direction, newshape=(num_dims, num_dims))

    # Convert to ants image
    img_ants = ants.from_numpy(
        img_numpy,
        spacing=img.GetSpacing(),
        origin=img.GetOrigin(),
        direction=direction
    )

    return img_ants


def resample_img(itk_image, out_spacing=[2.0, 1.0, 1.0]):
    """
    Spatially normalize image.
    Based on:
    https://blog.tensorflow.org/2018/07/an-introduction-to-biomedical-image-analysis-tensorflow-dltk.html
    """

    # Resample images to 2mm spacing with SimpleITK
    original_spacing = itk_image.GetSpacing()
    original_size = itk_image.GetSize()

    out_size = [
        int(np.round(original_size[0] * (original_spacing[0] / out_spacing[0]))),
        int(np.round(original_size[1] * (original_spacing[1] / out_spacing[1]))),
        int(np.round(original_size[2] * (original_spacing[2] / out_spacing[2])))]

    resample = sitk.ResampleImageFilter()
    resample.SetOutputSpacing(out_spacing)
    resample.SetSize(out_size)
    resample.SetOutputDirection(itk_image.GetDirection())
    resample.SetOutputOrigin(itk_image.GetOrigin())
    resample.SetTransform(sitk.Transform())
    resample.SetDefaultPixelValue(itk_image.GetPixelIDValue())
    resample.SetInterpolator(sitk.sitkBSpline)
    return resample.Execute(itk_image)


def center_crop(itk_img, out_size):
    """
    Crops around center to `out_size`.
    """
    # Check shapes are 3-D
    assert len(out_size) == 3
    orig_shape = np.asarray(itk_img.GetSize())
    assert len(orig_shape) == 3

    # Calculate start and end coordinates
    to_cut = orig_shape - np.asarray(out_size)
    to_cut_left = to_cut // 2
    to_cut_right = to_cut - to_cut_left
    dim_1_start, dim_2_start, dim_3_start = to_cut_left
    dim_1_end, dim_2_end, dim_3_end = -to_cut_right

    #  Crop the image
    return itk_img[dim_1_start:dim_1_end, dim_2_start:dim_2_end, dim_3_start:dim_3_end]


def standardize_masked(arr, mask):
    """
    Standardize the brain pixels.
    x' = (x - mean) / sd
    """
    arr = arr.copy()
    arr[mask == 1] = (arr[mask == 1] - np.mean(arr[mask == 1])) / np.std(arr[mask == 1])
    return arr


def dir_path(string):
    """
    Check string is a path to a directory.
    Used in the argparser.
    """
    if not pathlib.Path(string).is_dir():
        raise NotADirectoryError(string)
    return string


def find_t1_files(path):
    """
    Find t1 images recursively.

    :return:
        - Sorted list of .nii.gz files
        - Number of found files
    """
    files = pathlib.Path(path).rglob('*_T1w.nii.gz')
    files = sorted(files)
    return files, len(files)


def find_subject_folders(path):
    folders = pathlib.Path(path).glob('sub-*/')
    folders = sorted(folders)
    return folders, len(folders)


if __name__ == '__main__':
    """
    Will collect all t1w images directly in the subject's main folder.
    """
    arg_parser = argparse.ArgumentParser(description='Preprocess nifti files.')
    arg_parser.add_argument('input', type=dir_path, help='Path to input folder. Will recursively find .nii.gz files from here.')
    arg_parser.add_argument('output', type=dir_path, help='Path to output folder. Must exist.')
    args = arg_parser.parse_args()

    # Find subject folders
    subject_folders, num_subject_folders = find_subject_folders(args.input)

    print(f'Found {num_subject_folders} subject folders.')

    for f_idx, folder in enumerate(subject_folders):
        if f_idx % 25 == 0:
            print(f'At folder {f_idx+1}/{num_subject_folders}.')

        subject_id = folder.name
        abs_folder = folder.absolute()

        # Create the output dir path
        output_dir = pathlib.Path(args.output).absolute() / subject_id

        # Get t1w files for current subject
        t1_images, num_t1_images = find_t1_files(abs_folder)

        # Preprocess each file
        for img in t1_images:
            read_prep_save_image(input_file=str(img), output_dir=str(output_dir))
