extract_model_params <- function(summary){
  summary %>%
    dplyr::select(term, estimate) %>%
    dplyr::mutate(term = ifelse(term=="(Intercept)", "b0", "bx")) %>%
    tidyr::pivot_wider(names_from=term, values_from=estimate) %>%
    unlist()
}
