
# Sample with individual n for each group
sample_groupwise <- function(data, group_var, ns){
  # https://jennybc.github.io/purrr-tutorial/ls12_different-sized-samples.html

  data %>%
    dplyr::group_by(!!as.name(group_var)) %>%
    tidyr::nest() %>% # --> one row per group
    dplyr::ungroup() %>%
    dplyr::mutate(n = ns) %>% # add sample sizes
    dplyr::mutate(samp = purrr::map2(data, n, sample_n)) %>%  # Sample each group
    select(-data, -n) %>%
    unnest(samp)
}
